#!/bin/bash

# ===== BUA updater registration adapter =====
bua_github_release_register() {
    local bua_owner='batocera-unofficial-addons'
    local bua_repo='batocera-unofficial-addons'

    local bua_values

    bua_values=$(
        python3 - "$bua_owner" "$bua_repo" <<'PYBUAGH'
import hashlib
import json
import sys
import urllib.request

owner, repo = sys.argv[1:3]

url = (
    "https://api.github.com/repos/"
    f"{owner}/{repo}/releases/latest"
)

req = urllib.request.Request(
    url,
    headers={
        "User-Agent": "BUA-Updater",
        "Accept": "application/vnd.github+json",
        "Cache-Control": "no-cache",
    },
)

with urllib.request.urlopen(
    req,
    timeout=25,
) as response:
    release = json.loads(
        response.read().decode("utf-8")
    )

tag = str(
    release.get("tag_name") or ""
).strip()

if not tag:
    raise SystemExit(
        "GitHub release has no tag_name"
    )

assets = []

for asset in release.get("assets") or []:
    assets.append({
        "id": asset.get("id"),
        "name": asset.get("name"),
        "size": asset.get("size"),
        "updated_at": asset.get("updated_at"),
    })

identity_payload = {
    "release_id": release.get("id"),
    "release_updated_at": release.get("updated_at"),
    "assets": sorted(
        assets,
        key=lambda a: (
            str(a.get("name") or ""),
            str(a.get("id") or ""),
        ),
    ),
}

serialized = json.dumps(
    identity_payload,
    sort_keys=True,
    separators=(",", ":"),
).encode("utf-8")

digest = hashlib.sha256(
    serialized
).hexdigest()

identity = (
    "github-release:"
    + str(release.get("id") or "unknown")
    + ":"
    + digest
)

print(tag)
print(identity)
PYBUAGH
    ) || return 1

    local bua_version
    local bua_identity

    bua_version=$(
        printf '%s\n' "$bua_values" |
            sed -n '1p'
    )

    bua_identity=$(
        printf '%s\n' "$bua_values" |
            sed -n '2p'
    )

    if [[ -z "$bua_version" || -z "$bua_identity" ]]; then
        echo "Unable to determine GitHub release identity." >&2
        return 1
    fi

    bua_register \
        "$bua_version" \
        "github_release" \
        "$bua_owner" \
        "$bua_repo" \
        "custom" \
        "" \
        "" \
        "" \
        "$bua_identity"
}

if [[ "${BUA_REGISTRATION_ONLY:-0}" == "1" ]]; then
    if ! declare -F bua_register >/dev/null 2>&1; then
        echo "BUA registration helper is unavailable." >&2
        exit 1
    fi

    bua_github_release_register
    exit $?
fi
# ===== end BUA updater registration adapter =====


echo "Desktop for Batocera — Installer"
echo "================================="

TEMP_DIR="/userdata/tmp/Desktop_for_Batocera"
SFS_FILE="$TEMP_DIR/Desktop_for_Batocera.squashfs"
EXTRACT_DIR="$TEMP_DIR/extracted"
ADDON_NAME="desktop"
ADDON_DIR="/userdata/system/add-ons/${ADDON_NAME}"
DEST_DIR="${ADDON_DIR}/rootfs"
DRL_REMOVER="/userdata/system/configs/bat-drl/Remover_Desktop.sh"
BASE_URL="https://github.com/batocera-unofficial-addons/batocera-unofficial-addons/releases/download/AppImages"

ARCH=$(uname -m)
case "$ARCH" in
    x86_64)  SFS_URL="$BASE_URL/Desktop_for_batocera_8.8.squashfs" ;;
    aarch64) SFS_URL="$BASE_URL/Desktop_for_batocera_8.8_arm64.squashfs" ;;
    *)
        echo "Unsupported architecture: $ARCH"
        exit 1
        ;;
esac
cleanup_drl_rootfs_remnants() {
    echo "Cleaning up DRL rootfs remnants..."

    rm -f /usr/bin/antimicrox /usr/bin/zenity

    # Remove DRL overlay lib files by exact name via /overlay/overlay/.
    # Using wildcards through the merged /usr/lib path would create whiteouts for
    # Batocera-native libs (e.g. libgtk-3.so.0.2411.32, libnettle.so.8) that have
    # different version numbers from DRL's copies and are visible alongside them.
    # A wildcard on /overlay/overlay/ is also unsafe — other system libs (Nvidia etc)
    # live there too. Exact filenames sourced from the DRL squashfs are the only safe option.
    OVL=/overlay/overlay/usr/lib
    rm -f \
        "$OVL/libXtst.so"        "$OVL/libXtst.so.6"              "$OVL/libXtst.so.6.1.0" \
        "$OVL/libXv.so"          "$OVL/libXv.so.1"                "$OVL/libXv.so.1.0.0" \
        "$OVL/libaio.so"         "$OVL/libaio.so.1.0.1" \
        "$OVL/libadwaita-1.so.0" \
        "$OVL/libatk-bridge-2.0.so.0" \
        "$OVL/libatspi.so.0" \
        "$OVL/libbrotlicommon.so.1" \
        "$OVL/libbrotlidec.so.1" \
        "$OVL/libcanberra.so.0" \
        "$OVL/libcap.so.2.27" \
        "$OVL/libcprime-core.so"    "$OVL/libcprime-core.so.4"    "$OVL/libcprime-core.so.4.5.0" \
        "$OVL/libcprime-gui.so"     "$OVL/libcprime-gui.so.4"     "$OVL/libcprime-gui.so.4.5.0" \
        "$OVL/libcprime-widgets.so" "$OVL/libcprime-widgets.so.4" "$OVL/libcprime-widgets.so.4.5.0" \
        "$OVL/libcroco-0.6.so"   "$OVL/libcroco-0.6.so.3"        "$OVL/libcroco-0.6.so.3.0.1" \
        "$OVL/libcrypt.so.1"     "$OVL/libcrypt.so.2" \
        "$OVL/libcups.so.2" \
        "$OVL/libcurl-gnutls.so.4" \
        "$OVL/libdbus-glib-1.so.2" \
        "$OVL/libexslt.so"       "$OVL/libexslt.so.0.8.20" \
        "$OVL/libfdisk.so.1.1.0" \
        "$OVL/libfm-gtk.so"      "$OVL/libfm-gtk.so.4"           "$OVL/libfm-gtk.so.4.1.2" \
        "$OVL/libgailutil-3.so"  "$OVL/libgailutil-3.so.0"       "$OVL/libgailutil-3.so.0.0.0" \
        "$OVL/libgdk-3.so"       "$OVL/libgdk-3.so.0.2404.8" \
        "$OVL/libgdk-x11-2.0.so" "$OVL/libgdk-x11-2.0.so.0"     "$OVL/libgdk-x11-2.0.so.0.2400.32" \
        "$OVL/libgtk-3.so"       "$OVL/libgtk-3.so.0.2404.8" \
        "$OVL/libgtk-4.so.1" \
        "$OVL/libgtk-x11-2.0.so" "$OVL/libgtk-x11-2.0.so.0"     "$OVL/libgtk-x11-2.0.so.0.2400.32" \
        "$OVL/libImlib2.so"      "$OVL/libImlib2.so.1"           "$OVL/libImlib2.so.1.5.1" \
        "$OVL/libidn2.so.0" \
        "$OVL/libjack.so.0" \
        "$OVL/libkeyutils.so.1" \
        "$OVL/liblightspark.so.0.8.5" "$OVL/liblightsparkplugin.so" \
        "$OVL/libnettle.so.7" \
        "$OVL/libnsl.so.1" \
        "$OVL/libpepflashplayer.so" \
        "$OVL/libQt5DBus.so"     "$OVL/libQt5DBus.so.5"     "$OVL/libQt5DBus.so.5.15"    "$OVL/libQt5DBus.so.5.15.8" \
        "$OVL/libQt5X11Extras.so" "$OVL/libQt5X11Extras.so.5" "$OVL/libQt5X11Extras.so.5.15" "$OVL/libQt5X11Extras.so.5.15.8" \
        "$OVL/librsvg-2.so"      "$OVL/librsvg-2.so.2.40.20" \
        "$OVL/libsecret-1.so.0" \
        "$OVL/libselinux.so.1" \
        "$OVL/libSoundTouch.so"  "$OVL/libSoundTouch.so.1"       "$OVL/libSoundTouch.so.1.0.0" \
        "$OVL/libtdb.so.1" \
        "$OVL/libthai.so.0"      "$OVL/libthai.so.0.3"           "$OVL/libthai.so.0.3.1" \
        "$OVL/libunistring.so.2" \
        "$OVL/libwayland-client.so.0" \
        "$OVL/libwayland-cursor.so.0" \
        "$OVL/libwayland-egl.so.1" \
        "$OVL/libwayland-server.so.0" \
        "$OVL/libxslt.so"        "$OVL/libxslt.so.1.1.34" \
        "$OVL/libyaml-cpp.so"    "$OVL/libyaml-cpp.so.0.6"      "$OVL/libyaml-cpp.so.0.6.3" \
        2>/dev/null || true

    # Top-level /lib/ DRL files (DRL remover handles /overlay/overlay/lib/ but belt-and-suspenders)
    rm -f \
        /overlay/overlay/lib/libfdisk.so.1.1.0 \
        /overlay/overlay/lib/libthai.so.0.3.1 \
        2>/dev/null || true

    # Remove DRL overlay files that rmdir cannot handle
    rm -f  /overlay/overlay/etc/openbox/rc.xml 2>/dev/null || true
    rm -f  /overlay/overlay/etc/xdg/openbox/autostart.bak 2>/dev/null || true
    rm -rf /overlay/overlay/usr/share/icons/batocera/ 2>/dev/null || true

    rmdir \
        /etc/xdg/libfm \
        /etc/xdg/menus \
        /etc/xdg/pcmanfm/default \
        /etc/openbox \
        /etc/X11 \
        /usr/share/icons/batocera \
        2>/dev/null || true

    batocera-services stop symlink_manager 2>/dev/null || true
    batocera-services start symlink_manager >/dev/null 2>&1 &
}

# Detect existing DRL install
if [ -f "$DRL_REMOVER" ]; then
    dialog --title "Existing Desktop Detected" \
        --yesno "An existing Desktop for Batocera (DRL) installation was detected.\n\nIt must be removed before installing the new version.\n\nRun the uninstaller now?" 12 55
    if [ $? -eq 0 ]; then
        echo "Removing old DRL installation..."
        function yad() { return 0; }; export -f yad
        bash "$DRL_REMOVER"
        unset -f yad

        echo "Cleaning up DRL remnants..."
        rm -rf /userdata/system/Desktop
        rm -rf /userdata/system/configs/bat-drl/Desktop
        rm -rf /userdata/system/configs/bat-drl/tint2
        rm -rf /userdata/system/configs/bat-drl/AntiMicroX
        rm -rf /userdata/system/configs/bat-drl/FP_Atalho
        rm -f /userdata/system/configs/bat-drl/Nav_Redist2.joystick.amgp
        rm -rf /userdata/userdata
        rm -rf /userdata/system/add-ons/desktop_drl
        rm -f /userdata/system/services/desktop_drl
        rm -rf /userdata/system/.config/tint2
        rm -rf /userdata/system/.config/jgmenu
        rm -rf /userdata/system/.config/libfm
        rm -rf /userdata/system/.config/pcmanfm
        rm -rf /userdata/system/.config/sublime-text
        cleanup_drl_rootfs_remnants
        for proc in tint2 jgmenu pcmanfm xcompmgr picom; do
            pkill -x "$proc" 2>/dev/null || true
        done
    else
        echo "Installation cancelled."
        exit 0
    fi
fi

# Detect existing install — back up customisations before updating
BACKUP_DIR="$TEMP_DIR/backup"
IS_UPDATE=0
if [ -d "$ADDON_DIR/rootfs" ]; then
    IS_UPDATE=1
    echo "Existing install detected — backing up customisations..."
    mkdir -p "$BACKUP_DIR"
    [ -d /userdata/system/Desktop ]             && cp -r /userdata/system/Desktop             "$BACKUP_DIR/Desktop"
    [ -f /userdata/system/.config/tint2/tint2rc ] && cp /userdata/system/.config/tint2/tint2rc "$BACKUP_DIR/tint2rc"
    [ -d /userdata/system/.config/jgmenu ]      && cp -r /userdata/system/.config/jgmenu      "$BACKUP_DIR/jgmenu"
    [ -f /userdata/system/.config/pcmanfm/default/desktop-items-0.conf ] && \
        cp /userdata/system/.config/pcmanfm/default/desktop-items-0.conf "$BACKUP_DIR/desktop-items-0.conf"
    PALETTE_FILE="/userdata/system/add-ons/desktop/config/Desktop/theme/current.palette"
    BAR_CONF_FILE="/userdata/system/add-ons/desktop/config/Desktop/theme/bar.conf"
    [ -f "$PALETTE_FILE" ]  && cp "$PALETTE_FILE"  "$BACKUP_DIR/current.palette"
    [ -f "$BAR_CONF_FILE" ] && cp "$BAR_CONF_FILE" "$BACKUP_DIR/bar.conf"

    echo "Stopping desktop service..."
    batocera-services stop desktop

    echo "Removing renamed/obsolete files from rootfs..."
    # Binaries renamed from Portuguese
    rm -f "$DEST_DIR/usr/bin/flat-atalho"
    rm -f "$DEST_DIR/usr/bin/linksimb"
    rm -f "$DEST_DIR/usr/bin/tema"
    # Desktop files for renamed binaries
    rm -f "$DEST_DIR/usr/share/applications/linksimb.desktop"
    # Icon renamed
    rm -f "$DEST_DIR/usr/share/icons/batocera/tema.png"
fi

# Create temp directories
mkdir -p "$TEMP_DIR" "$EXTRACT_DIR" "$DEST_DIR"

# Download squashfs
echo "Downloading..."
curl -L -o "$SFS_FILE" "$SFS_URL"

if [ ! -f "$SFS_FILE" ]; then
    echo "Error: Download failed."
    exit 1
fi

# Extract
echo "Extracting..."
unsquashfs -f -d "$EXTRACT_DIR" "$SFS_FILE"

if [ $? -ne 0 ]; then
    echo "Error: Extraction failed."
    rm -rf "$TEMP_DIR"
    exit 1
fi

# userdata content goes directly to /userdata (persistent)
echo "Installing userdata files..."
cp -r "$EXTRACT_DIR/userdata/." /userdata/ 2>/dev/null || true

# Root FS content goes into rootfs for the service to symlink on each boot
echo "Installing root FS files..."
for dir in usr etc lib; do
    [ -d "$EXTRACT_DIR/$dir" ] && cp -r "$EXTRACT_DIR/$dir" "$DEST_DIR/" || true
done

# Icon packs
if [ -d "$EXTRACT_DIR/icons" ]; then
    echo "Installing icon packs..."
    cp -r "$EXTRACT_DIR/icons" "$ADDON_DIR/"
fi

# Restore customisations if updating
if [ "$IS_UPDATE" -eq 1 ]; then
    echo "Restoring customisations..."
    [ -d "$BACKUP_DIR/Desktop" ]       && rm -rf /userdata/system/Desktop && cp -r "$BACKUP_DIR/Desktop" /userdata/system/Desktop
    [ -f "$BACKUP_DIR/tint2rc" ]       && cp "$BACKUP_DIR/tint2rc" /userdata/system/.config/tint2/tint2rc
    [ -d "$BACKUP_DIR/jgmenu" ]        && rm -rf /userdata/system/.config/jgmenu && cp -r "$BACKUP_DIR/jgmenu" /userdata/system/.config/jgmenu
    [ -f "$BACKUP_DIR/desktop-items-0.conf" ] && \
        cp "$BACKUP_DIR/desktop-items-0.conf" /userdata/system/.config/pcmanfm/default/desktop-items-0.conf
    [ -f "$BACKUP_DIR/current.palette" ] && mkdir -p "$(dirname "$PALETTE_FILE")" && cp "$BACKUP_DIR/current.palette" "$PALETTE_FILE"
    [ -f "$BACKUP_DIR/bar.conf" ]       && cp "$BACKUP_DIR/bar.conf" "$BAR_CONF_FILE"

    # Re-apply system Desktop files from squashfs — overwrite any stale versions restored from backup
    echo "Updating system Desktop files..."
    cp -r "$EXTRACT_DIR/userdata/system/Desktop/." /userdata/system/Desktop/ 2>/dev/null || true
fi

# Cleanup
echo "Cleaning up..."
rm -rf "$TEMP_DIR"

# Write the desktop service script
echo "Installing desktop service..."
mkdir -p /userdata/system/services
cat << 'SERVICEEOF' > /userdata/system/services/desktop
#!/bin/bash

ADDON_NAME="desktop"
ADDON_DIR="/userdata/system/add-ons/${ADDON_NAME}"
ROOTFS="${ADDON_DIR}/rootfs"
ICONS_DIR="${ADDON_DIR}/icons"
LOG="/userdata/system/logs/${ADDON_NAME}.log"

log() { echo "$(date): $*" | tee -a "$LOG"; }

link_file() {
    local src="$1"
    local target="${src#${ROOTFS}}"
    mkdir -p "$(dirname "$target")"

    if [ -L "$target" ]; then
        local cur; cur="$(readlink "$target")"
        if [ "$cur" = "$src" ]; then
            return
        else
            log "Conflict: $target -> $cur (expected $src). Skipping."
            return
        fi
    elif [ -e "$target" ]; then
        log "Backing up: $target -> ${target}.bak"
        mv "$target" "${target}.bak"
    fi

    log "Linking: $target -> $src"
    ln -s "$src" "$target"
}

unlink_file() {
    local src="$1"
    local target="${src#${ROOTFS}}"

    if [ -L "$target" ]; then
        local cur; cur="$(readlink "$target")"
        if [ "$cur" = "$src" ]; then
            log "Removing symlink: $target"
            rm "$target"
            [ -e "${target}.bak" ] && { log "Restoring: ${target}.bak"; mv "${target}.bak" "$target"; }
        else
            log "Symlink $target -> $cur, not our file. Skipping."
        fi
    elif [ -e "${target}.bak" ]; then
        log "Orphan backup found — restoring: ${target}.bak"
        mv "${target}.bak" "$target"
    fi
}

apply_symlinks() {
    [ -d "$ROOTFS" ] || { log "ERROR: rootfs missing at $ROOTFS"; exit 1; }
    find "$ROOTFS" \( -type f -o -type l \) \
        ! -path "${ROOTFS}/usr/share/themes/*" \
        ! -path "${ROOTFS}/usr/share/tint2/*/*" \
        ! -path "${ROOTFS}/usr/share/icons/*" \
        ! -path "${ROOTFS}/usr/share/desktop-palettes/*" \
        ! -path "${ROOTFS}/etc/openbox/rc.xml" \
        | while read -r src; do link_file "$src"; done
    log "Symlink pass complete."
}

remove_symlinks() {
    [ -d "$ROOTFS" ] || { log "rootfs missing, nothing to remove."; return; }
    find "$ROOTFS" \( -type f -o -type l \) \
        ! -path "${ROOTFS}/usr/share/themes/*" \
        ! -path "${ROOTFS}/usr/share/tint2/*/*" \
        ! -path "${ROOTFS}/usr/share/icons/*" \
        ! -path "${ROOTFS}/usr/share/desktop-palettes/*" \
        ! -path "${ROOTFS}/etc/openbox/rc.xml" \
        | while read -r src; do unlink_file "$src"; done
    log "Symlink removal complete."
}

link_dir_packs() {
    local src_dir="$1" target_parent="$2"
    [ -d "$src_dir" ] || return
    local pack target
    for pack in "$src_dir"/*/; do
        [ -d "$pack" ] || continue
        pack="${pack%/}"
        target="${target_parent}/$(basename "$pack")"
        if [ ! -e "$target" ] && [ ! -L "$target" ]; then
            log "Linking: $target -> $pack"
            ln -s "$pack" "$target"
        fi
    done
}

unlink_dir_packs() {
    local src_dir="$1" target_parent="$2"
    [ -d "$src_dir" ] || return
    local pack target
    for pack in "$src_dir"/*/; do
        [ -d "$pack" ] || continue
        pack="${pack%/}"
        target="${target_parent}/$(basename "$pack")"
        if [ -L "$target" ] && [ "$(readlink "$target")" = "$pack" ]; then
            log "Removing symlink: $target"
            rm "$target"
        fi
    done
}

link_files_into_dir() {
    local src_dir="$1" target_dir="$2"
    [ -d "$src_dir" ] || return
    mkdir -p "$target_dir"
    local src target
    for src in "$src_dir"/*; do
        [ -e "$src" ] || continue
        target="${target_dir}/$(basename "$src")"
        if [ ! -e "$target" ] && [ ! -L "$target" ]; then
            log "Linking: $target -> $src"
            ln -s "$src" "$target"
        fi
    done
}

unlink_files_from_dir() {
    local src_dir="$1" target_dir="$2"
    [ -d "$src_dir" ] || return
    local src target
    for src in "$src_dir"/*; do
        [ -e "$src" ] || continue
        target="${target_dir}/$(basename "$src")"
        if [ -L "$target" ] && [ "$(readlink "$target")" = "$src" ]; then
            log "Removing symlink: $target"
            rm "$target"
        fi
    done
}

link_dir() {
    local src="$1" target="$2"
    if [ -L "$target" ] && [ "$(readlink "$target")" = "$src" ]; then return; fi
    if [ -e "$target" ]; then
        log "Backing up: $target -> ${target}.bak"
        mv "$target" "${target}.bak"
    fi
    log "Linking dir: $target -> $src"
    ln -s "$src" "$target"
}

unlink_dir() {
    local src="$1" target="$2"
    if [ -L "$target" ] && [ "$(readlink "$target")" = "$src" ]; then
        log "Removing dir symlink: $target"
        rm "$target"
        [ -e "${target}.bak" ] && { log "Restoring: ${target}.bak"; mv "${target}.bak" "$target"; }
    fi
}

link_icon_packs() {
    [ -d "$ICONS_DIR" ] || return
    local pack target
    for pack in "$ICONS_DIR"/*/; do
        [ -d "$pack" ] || continue
        pack="${pack%/}"
        target="/usr/share/icons/$(basename "$pack")"
        if [ ! -e "$target" ] && [ ! -L "$target" ]; then
            log "Linking icon pack: $target -> $pack"
            ln -s "$pack" "$target"
        fi
    done
}

unlink_icon_packs() {
    [ -d "$ICONS_DIR" ] || return
    local pack target
    for pack in "$ICONS_DIR"/*/; do
        [ -d "$pack" ] || continue
        pack="${pack%/}"
        target="/usr/share/icons/$(basename "$pack")"
        if [ -L "$target" ] && [ "$(readlink "$target")" = "$pack" ]; then
            log "Removing icon pack symlink: $target"
            rm "$target"
        fi
    done
}

case "$1" in
    start)
        mkdir -p /userdata/system/logs
        log "Starting desktop overlay..."
        apply_symlinks
        link_icon_packs
        link_dir_packs "${ROOTFS}/usr/share/icons" "/usr/share/icons"
        link_files_into_dir "${ROOTFS}/usr/share/icons/batocera" "/usr/share/icons/batocera"
        link_dir_packs "${ROOTFS}/usr/share/themes" "/usr/share/themes"
        link_dir_packs "${ROOTFS}/usr/share/tint2" "/usr/share/tint2"
        link_dir "${ROOTFS}/usr/share/desktop-palettes" "/usr/share/desktop-palettes"
        ;;
    stop)
        mkdir -p /userdata/system/logs
        log "Stopping desktop overlay..."
        remove_symlinks
        unlink_icon_packs
        unlink_dir_packs "${ROOTFS}/usr/share/icons" "/usr/share/icons"
        unlink_files_from_dir "${ROOTFS}/usr/share/icons/batocera" "/usr/share/icons/batocera"
        unlink_dir_packs "${ROOTFS}/usr/share/themes" "/usr/share/themes"
        unlink_dir_packs "${ROOTFS}/usr/share/tint2" "/usr/share/tint2"
        unlink_dir "${ROOTFS}/usr/share/desktop-palettes" "/usr/share/desktop-palettes"
        ;;
    status)
        if [ ! -d "$ROOTFS" ]; then
            echo "desktop: not installed (rootfs missing)."
            exit 1
        fi
        missing=0
        while IFS= read -r src; do
            target="${src#${ROOTFS}}"
            [ -L "$target" ] && [ "$(readlink "$target")" = "$src" ] || missing=$((missing+1))
        done < <(find "$ROOTFS" \( -type f -o -type l \))
        [ "$missing" -eq 0 ] && echo "desktop: all symlinks active." \
                              || echo "desktop: ${missing} symlink(s) missing or broken."
        ;;
    *)
        echo "Usage: $0 {start|stop|status}"
        exit 1
        ;;
esac
SERVICEEOF

chmod +x /userdata/system/services/desktop

# Enable and start the service
batocera-services enable desktop
batocera-services start desktop

# Install our rc.xml as the base openbox config so it's active even outside desktop mode
RC_DESKTOP="/userdata/system/add-ons/desktop/rc.xml.desktop"
RC_ES="/userdata/system/add-ons/desktop/rc.xml.es"
[ -f "$RC_DESKTOP" ] && cp "$RC_DESKTOP" /etc/openbox/rc.xml
[ -f "$RC_ES" ]      && cp "$RC_ES"      /etc/openbox/rc.xml.es
openbox --reconfigure >/dev/null 2>&1 || true

# Apply palette icons (service must be running for paths to resolve)
if [ "$IS_UPDATE" -eq 1 ] && [ -f "$PALETTE_FILE" ]; then
    PALETTE_NAME=$(cat "$PALETTE_FILE" | tr -d '[:space:]')
    ICONS_SRC="/usr/share/desktop-palettes/icons/palettes/$PALETTE_NAME"
    if [ -d "$ICONS_SRC" ]; then
        echo "Reapplying palette icons ($PALETTE_NAME)..."
        cp "$ICONS_SRC"/* /usr/share/icons/batocera/ 2>/dev/null || true
    fi
else
    ICONS_SRC="/usr/share/desktop-palettes/icons/palettes/blue"
    if [ -d "$ICONS_SRC" ]; then
        echo "Applying default palette icons (blue)..."
        cp "$ICONS_SRC"/* /usr/share/icons/batocera/ 2>/dev/null || true
    fi
fi

echo ""
if [ "$IS_UPDATE" -eq 1 ]; then
    echo "Update complete."
else
    echo "Installation complete. Please restart for changes to take effect."
fi


# ===== BUA post-install registration =====
if declare -F bua_register >/dev/null 2>&1; then
    bua_github_release_register || true
fi
# ===== end BUA post-install registration =====

